"use strict";
/**
 *  Volume 1:
 *     section 3, video 1:
 *        What Are Partial Application and Currying
 *
 *     There is no code for this video.
 */
