"use strict";
/**
 *  Volume 1:
 *     section 2, video 2:
 *         Replacing Loops with Higher-Order Functions
 */

const list = [12, 6, 4, 66, 4, 5];


for (let i = 0; i < list.length; i++) {
  const item = list[i];
  // Do something with item
}


let i = list.length;
while (i--) {
  const item = list[i];
  // Do something with item
}


//debugger;
