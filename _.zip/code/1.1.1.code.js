"use strict";
/**
 *  Volume 1:
 *     section 1, video 1:
 *         Refactoring Impure Functions
 */

const people = ['Robert', 'Arya', ['Catelyn' ], 'Tyrion'];
let lives = 3;


function playerLostImpure() {
  lives--;
}


function addPersonImpure() {
  people.push(name);
}


//debugger;
